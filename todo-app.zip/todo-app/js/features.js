/**
 * Features Module
 * Handles advanced features like gamification, cloud sync, etc.
 */

const Features = (function() {
    // DOM Elements
    const elements = {
        // Gamification
        pointsDisplay: null, // Will be created if needed
        badgesContainer: null, // Will be created if needed
        
        // Cloud sync
        syncStatus: null, // Will be created if needed
        syncButton: null, // Will be created if needed
        
        // Swipe gestures
        taskList: document.getElementById('task-list')
    };
    
    // State
    let touchStartX = 0;
    let touchStartY = 0;
    let touchEndX = 0;
    let touchEndY = 0;
    let currentTaskElement = null;
    
    // Gamification data
    const gamificationData = {
        points: 0,
        level: 1,
        badges: [],
        achievements: [
            { id: 'first-task', name: 'First Step', description: 'Complete your first task', icon: 'fa-baby', points: 10 },
            { id: 'task-master', name: 'Task Master', description: 'Complete 10 tasks', icon: 'fa-crown', points: 50 },
            { id: 'speed-demon', name: 'Speed Demon', description: 'Complete 5 tasks in one day', icon: 'fa-bolt', points: 30 },
            { id: 'perfectionist', name: 'Perfectionist', description: 'Complete 20 tasks without missing any', icon: 'fa-star', points: 100 },
            { id: 'early-bird', name: 'Early Bird', description: 'Complete a task before its due date', icon: 'fa-cock', points: 20 },
            { id: 'night-owl', name: 'Night Owl', description: 'Complete a task after 10 PM', icon: 'fa-moon', points: 15 }
        ]
    };
    
    /**
     * Initialize features
     */
    const init = function() {
        // Load gamification data
        loadGamificationData();
        
        // Initialize swipe gestures
        initSwipeGestures();
        
        // Check for cloud sync
        checkCloudSync();
        
        // Request notification permission
        requestNotificationPermission();
        
        // Initialize service worker for offline support
        initServiceWorker();
    };
    
    /**
     * Load gamification data
     */
    const loadGamificationData = function() {
        const savedData = localStorage.getItem('taskmaster_gamification');
        if (savedData) {
            const parsed = JSON.parse(savedData);
            gamificationData.points = parsed.points || 0;
            gamificationData.level = parsed.level || 1;
            gamificationData.badges = parsed.badges || [];
        }
        
        // Create UI elements for gamification
        createGamificationUI();
        
        // Update UI
        updateGamificationUI();
    };
    
    /**
     * Save gamification data
     */
    const saveGamificationData = function() {
        localStorage.setItem('taskmaster_gamification', JSON.stringify(gamificationData));
    };
    
    /**
     * Create gamification UI elements
     */
    const createGamificationUI = function() {
        // Create points display
        const headerControls = document.querySelector('.header-controls');
        
        const pointsContainer = document.createElement('div');
        pointsContainer.className = 'points-container';
        
        const pointsDisplay = document.createElement('div');
        pointsDisplay.className = 'points-display';
        pointsDisplay.innerHTML = `<i class="fas fa-coins"></i> <span id="points-value">${gamificationData.points}</span> pts`;
        
        const levelDisplay = document.createElement('div');
        levelDisplay.className = 'level-display';
        levelDisplay.innerHTML = `Level <span id="level-value">${gamificationData.level}</span>`;
        
        pointsContainer.appendChild(pointsDisplay);
        pointsContainer.appendChild(levelDisplay);
        
        headerControls.insertBefore(pointsContainer, headerControls.firstChild);
        
        // Create badges container in the main content
        const mainContent = document.querySelector('.app-main');
        
        const badgesSection = document.createElement('div');
        badgesSection.className = 'badges-section';
        badgesSection.innerHTML = `
            <h3>Your Badges</h3>
            <div id="badges-container" class="badges-container">
                <!-- Badges will be added here -->
            </div>
        `;
        
        // Insert after stats container
        const statsContainer = document.querySelector('.stats-container');
        mainContent.insertBefore(badgesSection, statsContainer.nextSibling);
        
        // Store references
        elements.pointsDisplay = document.getElementById('points-value');
        elements.levelDisplay = document.getElementById('level-value');
        elements.badgesContainer = document.getElementById('badges-container');
    };
    
    /**
     * Update gamification UI
     */
    const updateGamificationUI = function() {
        if (elements.pointsDisplay) {
            elements.pointsDisplay.textContent = gamificationData.points;
        }
        
        if (elements.levelDisplay) {
            elements.levelDisplay.textContent = gamificationData.level;
        }
        
        if (elements.badgesContainer) {
            elements.badgesContainer.innerHTML = '';
            
            if (gamificationData.badges.length === 0) {
                elements.badgesContainer.innerHTML = '<p class="no-badges">Complete tasks to earn badges!</p>';
                return;
            }
            
            gamificationData.badges.forEach(badgeId => {
                const achievement = gamificationData.achievements.find(a => a.id === badgeId);
                if (achievement) {
                    const badgeElement = document.createElement('div');
                    badgeElement.className = 'badge';
                    badgeElement.innerHTML = `
                        <div class="badge-icon">
                            <i class="fas ${achievement.icon}"></i>
                        </div>
                        <div class="badge-info">
                            <div class="badge-name">${achievement.name}</div>
                            <div class="badge-description">${achievement.description}</div>
                        </div>
                    `;
                    elements.badgesContainer.appendChild(badgeElement);
                }
            });
        }
    };
    
    /**
     * Add points for completing a task
     * @param {Object} task - Completed task
     */
    const addTaskCompletionPoints = function(task) {
        // Base points for completing a task
        let points = 5;
        
        // Bonus points for high priority tasks
        if (task.priority === 'high') {
            points += 5;
        } else if (task.priority === 'medium') {
            points += 2;
        }
        
        // Bonus points for completing before due date
        if (task.dueDate) {
            const dueDate = new Date(task.dueDate);
            const now = new Date();
            if (dueDate > now) {
                points += 3;
                checkAndUnlockAchievement('early-bird');
            }
        }
        
        // Bonus points for completing tasks at night
        const hour = new Date().getHours();
        if (hour >= 22 || hour <= 6) {
            points += 2;
            checkAndUnlockAchievement('night-owl');
        }
        
        // Add points
        gamificationData.points += points;
        
        // Check for level up
        const newLevel = Math.floor(gamificationData.points / 50) + 1;
        if (newLevel > gamificationData.level) {
            gamificationData.level = newLevel;
            UI.showNotification(`Level up! You are now level ${gamificationData.level}`, 'success');
        }
        
        // Save and update UI
        saveGamificationData();
        updateGamificationUI();
        
        // Show points notification
        UI.showNotification(`+${points} points!`, 'success');
        
        // Check for achievements
        checkAndUnlockAchievement('first-task');
        
        // Get all completed tasks
        const tasks = Storage.getTasks();
        const completedTasks = tasks.filter(t => t.completed);
        
        if (completedTasks.length >= 10) {
            checkAndUnlockAchievement('task-master');
        }
        
        if (completedTasks.length >= 20) {
            checkAndUnlockAchievement('perfectionist');
        }
        
        // Check for speed demon (5 tasks in one day)
        const today = new Date().toDateString();
        const todayTasks = completedTasks.filter(task => {
            const completedDate = new Date(task.updatedAt).toDateString();
            return completedDate === today;
        });
        
        if (todayTasks.length >= 5) {
            checkAndUnlockAchievement('speed-demon');
        }
    };
    
    /**
     * Check and unlock achievement
     * @param {string} achievementId - Achievement ID
     */
    const checkAndUnlockAchievement = function(achievementId) {
        // Check if already unlocked
        if (gamificationData.badges.includes(achievementId)) {
            return;
        }
        
        const achievement = gamificationData.achievements.find(a => a.id === achievementId);
        if (!achievement) return;
        
        // Add badge
        gamificationData.badges.push(achievementId);
        gamificationData.points += achievement.points;
        
        // Save and update UI
        saveGamificationData();
        updateGamificationUI();
        
        // Show notification
        UI.showNotification(`Achievement unlocked: ${achievement.name}! +${achievement.points} points`, 'success');
    };
    
    /**
     * Initialize swipe gestures
     */
    const initSwipeGestures = function() {
        // Only initialize on touch devices
        if (!('ontouchstart' in window)) return;
        
        elements.taskList.addEventListener('touchstart', handleTouchStart, { passive: true });
        elements.taskList.addEventListener('touchmove', handleTouchMove, { passive: true });
        elements.taskList.addEventListener('touchend', handleTouchEnd, { passive: true });
    };
    
    /**
     * Handle touch start
     * @param {TouchEvent} e - Touch event
     */
    const handleTouchStart = function(e) {
        touchStartX = e.changedTouches[0].screenX;
        touchStartY = e.changedTouches[0].screenY;
        
        // Get the task element
        const touchElement = document.elementFromPoint(
            e.changedTouches[0].clientX,
            e.changedTouches[0].clientY
        );
        
        if (touchElement) {
            currentTaskElement = touchElement.closest('.task-item');
        }
    };
    
    /**
     * Handle touch move
     * @param {TouchEvent} e - Touch event
     */
    const handleTouchMove = function(e) {
        if (!currentTaskElement) return;
        
        touchEndX = e.changedTouches[0].screenX;
        touchEndY = e.changedTouches[0].screenY;
        
        // Calculate swipe distance
        const deltaX = touchEndX - touchStartX;
        const deltaY = touchEndY - touchStartY;
        
        // Only handle horizontal swipes
        if (Math.abs(deltaX) > Math.abs(deltaY)) {
            // Apply visual feedback
            currentTaskElement.style.transform = `translateX(${deltaX}px)`;
            currentTaskElement.style.transition = 'transform 0.1s ease';
        }
    };
    
    /**
     * Handle touch end
     * @param {TouchEvent} e - Touch event
     */
    const handleTouchEnd = function(e) {
        if (!currentTaskElement) return;
        
        touchEndX = e.changedTouches[0].screenX;
        touchEndY = e.changedTouches[0].screenY;
        
        // Calculate swipe distance
        const deltaX = touchEndX - touchStartX;
        const deltaY = touchEndY - touchStartY;
        
        // Reset transform
        currentTaskElement.style.transform = '';
        currentTaskElement.style.transition = '';
        
        // Only handle horizontal swipes with sufficient distance
        if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 50) {
            const taskId = currentTaskElement.dataset.id;
            
            if (deltaX > 0) {
                // Swipe right - mark as complete
                const tasks = Storage.getTasks();
                const task = tasks.find(t => t.id === taskId);
                
                if (task && !task.completed) {
                    UI.toggleTaskCompletion(taskId);
                    addTaskCompletionPoints(task);
                }
            } else {
                // Swipe left - delete
                UI.deleteTask(taskId);
            }
        }
        
        currentTaskElement = null;
    };
    
    /**
     * Check for cloud sync
     */
    const checkCloudSync = function() {
        // This is a placeholder for cloud sync functionality
        // In a real implementation, this would connect to a backend API
        
        // Create sync UI elements
        const headerControls = document.querySelector('.header-controls');
        
        const syncContainer = document.createElement('div');
        syncContainer.className = 'sync-container';
        
        const syncButton = document.createElement('button');
        syncButton.className = 'btn btn-icon';
        syncButton.innerHTML = '<i class="fas fa-sync-alt"></i>';
        syncButton.title = 'Sync with cloud';
        syncButton.addEventListener('click', syncWithCloud);
        
        const syncStatus = document.createElement('div');
        syncStatus.className = 'sync-status';
        syncStatus.innerHTML = '<i class="fas fa-check-circle"></i>';
        syncStatus.title = 'Last synced: Just now';
        
        syncContainer.appendChild(syncButton);
        syncContainer.appendChild(syncStatus);
        
        headerControls.appendChild(syncContainer);
        
        // Store references
        elements.syncButton = syncButton;
        elements.syncStatus = syncStatus;
    };
    
    /**
     * Sync with cloud
     */
    const syncWithCloud = function() {
        if (!elements.syncButton) return;
        
        // Add spinning animation
        const syncIcon = elements.syncButton.querySelector('i');
        syncIcon.classList.add('fa-spin');
        
        // Simulate sync process
        setTimeout(() => {
            // Remove spinning animation
            syncIcon.classList.remove('fa-spin');
            
            // Update status
            elements.syncStatus.innerHTML = '<i class="fas fa-check-circle"></i>';
            elements.syncStatus.title = 'Last synced: ' + new Date().toLocaleTimeString();
            
            // Show notification
            UI.showNotification('Tasks synced with cloud', 'success');
        }, 1500);
    };
    
    /**
     * Request notification permission
     */
    const requestNotificationPermission = function() {
        if (!('Notification' in window)) {
            console.log('This browser does not support notifications');
            return;
        }
        
        // Check if permission is already granted
        if (Notification.permission === 'granted') {
            return;
        }
        
        // Check if permission is denied
        if (Notification.permission === 'denied') {
            console.log('Notification permission denied');
            return;
        }
        
        // Request permission
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                console.log('Notification permission granted');
            } else {
                console.log('Notification permission denied');
            }
        });
    };
    
    /**
     * Initialize service worker
     */
    const initServiceWorker = function() {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.ready.then(registration => {
                console.log('ServiceWorker registration successful with scope: ', registration.scope);
                
                // Check for updates
                registration.addEventListener('updatefound', () => {
                    const installingWorker = registration.installing;
                    installingWorker.addEventListener('statechange', () => {
                        if (installingWorker.state === 'installed' && navigator.serviceWorker.controller) {
                            // New version available
                            UI.showNotification('A new version is available. Refresh to update.', 'info');
                        }
                    });
                });
            }).catch(error => {
                console.log('ServiceWorker registration failed: ', error);
            });
        }
    };
    
    // Public API
    return {
        init,
        addTaskCompletionPoints
    };
})();