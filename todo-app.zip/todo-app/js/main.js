/**
 * Main Application Entry Point
 */

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize UI
    UI.init();
    
    // Initialize features
    Features.init();
    
    // Add event listener for task completion to award points
    document.addEventListener('change', function(e) {
        if (e.target.classList.contains('task-checkbox') && e.target.checked) {
            const taskItem = e.target.closest('.task-item');
            if (taskItem) {
                const taskId = taskItem.dataset.id;
                const tasks = Storage.getTasks();
                const task = tasks.find(t => t.id === taskId);
                
                if (task) {
                    Features.addTaskCompletionPoints(task);
                }
            }
        }
    });
    
    // Add CSS for gamification elements
    const style = document.createElement('style');
    style.textContent = `
        .points-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
        }
        
        .points-display {
            display: flex;
            align-items: center;
            gap: 0.25rem;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .level-display {
            font-size: 0.75rem;
            color: var(--secondary-color);
        }
        
        .badges-section {
            margin-bottom: 2rem;
        }
        
        .badges-section h3 {
            font-size: 1.125rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }
        
        .badges-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .badge {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem;
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }
        
        .badge:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        }
        
        .badge-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 2.5rem;
            height: 2.5rem;
            border-radius: 50%;
            background-color: rgba(74, 108, 247, 0.1);
            color: var(--primary-color);
            flex-shrink: 0;
        }
        
        .badge-info {
            flex: 1;
        }
        
        .badge-name {
            font-weight: 600;
            margin-bottom: 0.125rem;
        }
        
        .badge-description {
            font-size: 0.75rem;
            color: var(--secondary-color);
        }
        
        .no-badges {
            grid-column: 1 / -1;
            text-align: center;
            padding: 1rem;
            color: var(--secondary-color);
        }
        
        .sync-container {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .sync-status {
            color: var(--success-color);
        }
        
        .recording {
            background-color: var(--danger-color) !important;
            color: var(--white) !important;
            animation: pulse 1.5s infinite;
        }
        
        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7);
            }
            70% {
                box-shadow: 0 0 0 10px rgba(239, 68, 68, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(239, 68, 68, 0);
            }
        }
        
        .sortable-ghost {
            opacity: 0.4;
        }
        
        .sortable-chosen {
            background-color: rgba(74, 108, 247, 0.1);
        }
        
        .sortable-drag {
            opacity: 0.8;
        }
        
        @media (max-width: 768px) {
            .badges-container {
                grid-template-columns: 1fr;
            }
            
            .points-container {
                flex-direction: row;
                gap: 1rem;
            }
        }
    `;
    
    document.head.appendChild(style);
    
    // Log initialization
    console.log('TaskMaster Pro initialized successfully!');
});