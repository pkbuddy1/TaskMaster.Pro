/**
 * Storage Module
 * Handles local storage operations for tasks and settings
 */

const Storage = (function() {
    // Storage keys
    const TASKS_KEY = 'taskmaster_tasks';
    const SETTINGS_KEY = 'taskmaster_settings';
    
    // Default settings
    const defaultSettings = {
        theme: 'light',
        notifications: true,
        sound: true,
        autoBackup: false,
        lastBackup: null
    };
    
    /**
     * Get all tasks from local storage
     * @returns {Array} Array of task objects
     */
    const getTasks = function() {
        const tasksJSON = localStorage.getItem(TASKS_KEY);
        return tasksJSON ? JSON.parse(tasksJSON) : [];
    };
    
    /**
     * Save tasks to local storage
     * @param {Array} tasks - Array of task objects
     */
    const saveTasks = function(tasks) {
        localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
    };
    
    /**
     * Get settings from local storage
     * @returns {Object} Settings object
     */
    const getSettings = function() {
        const settingsJSON = localStorage.getItem(SETTINGS_KEY);
        return settingsJSON ? { ...defaultSettings, ...JSON.parse(settingsJSON) } : defaultSettings;
    };
    
    /**
     * Save settings to local storage
     * @param {Object} settings - Settings object
     */
    const saveSettings = function(settings) {
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    };
    
    /**
     * Add a new task
     * @param {Object} task - Task object
     * @returns {Object} Added task with ID
     */
    const addTask = function(task) {
        const tasks = getTasks();
        
        // Create a new task object with ID and timestamps
        const newTask = {
            id: Date.now().toString(),
            text: task.text || '',
            completed: false,
            dueDate: task.dueDate || null,
            category: task.category || 'personal',
            priority: task.priority || 'medium',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        tasks.push(newTask);
        saveTasks(tasks);
        
        return newTask;
    };
    
    /**
     * Update an existing task
     * @param {string} id - Task ID
     * @param {Object} updates - Updates to apply
     * @returns {Object|null} Updated task or null if not found
     */
    const updateTask = function(id, updates) {
        const tasks = getTasks();
        const taskIndex = tasks.findIndex(task => task.id === id);
        
        if (taskIndex === -1) return null;
        
        // Update task properties
        tasks[taskIndex] = {
            ...tasks[taskIndex],
            ...updates,
            updatedAt: new Date().toISOString()
        };
        
        saveTasks(tasks);
        return tasks[taskIndex];
    };
    
    /**
     * Delete a task
     * @param {string} id - Task ID
     * @returns {boolean} True if task was deleted, false if not found
     */
    const deleteTask = function(id) {
        const tasks = getTasks();
        const initialLength = tasks.length;
        
        const filteredTasks = tasks.filter(task => task.id !== id);
        
        if (filteredTasks.length === initialLength) return false;
        
        saveTasks(filteredTasks);
        return true;
    };
    
    /**
     * Toggle task completion status
     * @param {string} id - Task ID
     * @returns {Object|null} Updated task or null if not found
     */
    const toggleTaskCompletion = function(id) {
        const tasks = getTasks();
        const taskIndex = tasks.findIndex(task => task.id === id);
        
        if (taskIndex === -1) return null;
        
        tasks[taskIndex].completed = !tasks[taskIndex].completed;
        tasks[taskIndex].updatedAt = new Date().toISOString();
        
        saveTasks(tasks);
        return tasks[taskIndex];
    };
    
    /**
     * Clear all completed tasks
     * @returns {number} Number of tasks deleted
     */
    const clearCompletedTasks = function() {
        const tasks = getTasks();
        const completedTasks = tasks.filter(task => task.completed);
        const activeTasks = tasks.filter(task => !task.completed);
        
        if (activeTasks.length === tasks.length) return 0;
        
        saveTasks(activeTasks);
        return completedTasks.length;
    };
    
    /**
     * Export tasks as JSON
     * @returns {string} JSON string of tasks
     */
    const exportTasks = function() {
        const tasks = getTasks();
        return JSON.stringify(tasks, null, 2);
    };
    
    /**
     * Import tasks from JSON
     * @param {string} tasksJSON - JSON string of tasks
     * @returns {Object} Result with success and message
     */
    const importTasks = function(tasksJSON) {
        try {
            const tasks = JSON.parse(tasksJSON);
            
            // Validate that it's an array
            if (!Array.isArray(tasks)) {
                return { success: false, message: 'Invalid format: expected an array of tasks' };
            }
            
            // Validate each task has required fields
            const validTasks = tasks.filter(task => {
                return task.id && typeof task.text === 'string';
            });
            
            if (validTasks.length === 0) {
                return { success: false, message: 'No valid tasks found in the import file' };
            }
            
            // Merge with existing tasks, avoiding duplicates
            const existingTasks = getTasks();
            const existingIds = existingTasks.map(task => task.id);
            const newTasks = validTasks.filter(task => !existingIds.includes(task.id));
            
            if (newTasks.length === 0) {
                return { success: false, message: 'All tasks already exist' };
            }
            
            const mergedTasks = [...existingTasks, ...newTasks];
            saveTasks(mergedTasks);
            
            return { 
                success: true, 
                message: `Successfully imported ${newTasks.length} task${newTasks.length !== 1 ? 's' : ''}` 
            };
        } catch (error) {
            return { success: false, message: 'Error parsing JSON file' };
        }
    };
    
    /**
     * Reset all data
     */
    const resetData = function() {
        localStorage.removeItem(TASKS_KEY);
        localStorage.removeItem(SETTINGS_KEY);
    };
    
    /**
     * Backup data
     * @returns {Object} Backup data
     */
    const backupData = function() {
        const backup = {
            tasks: getTasks(),
            settings: getSettings(),
            date: new Date().toISOString()
        };
        
        return backup;
    };
    
    /**
     * Restore data from backup
     * @param {Object} backup - Backup data
     * @returns {Object} Result with success and message
     */
    const restoreData = function(backup) {
        try {
            if (!backup.tasks || !backup.settings) {
                return { success: false, message: 'Invalid backup file' };
            }
            
            saveTasks(backup.tasks);
            saveSettings(backup.settings);
            
            return { success: true, message: 'Data restored successfully' };
        } catch (error) {
            return { success: false, message: 'Error restoring data' };
        }
    };
    
    // Public API
    return {
        getTasks,
        saveTasks,
        getSettings,
        saveSettings,
        addTask,
        updateTask,
        deleteTask,
        toggleTaskCompletion,
        clearCompletedTasks,
        exportTasks,
        importTasks,
        resetData,
        backupData,
        restoreData
    };
})();