/**
 * UI Module
 * Handles all UI interactions and updates
 */

const UI = (function() {
    // DOM Elements
    const elements = {
        // Theme
        themeToggle: document.getElementById('theme-toggle'),
        
        // Task Form
        taskForm: document.getElementById('task-form'),
        taskInput: document.getElementById('task-input'),
        taskDate: document.getElementById('task-date'),
        taskCategory: document.getElementById('task-category'),
        taskPriority: document.getElementById('task-priority'),
        addTaskBtn: document.getElementById('add-task-btn'),
        saveTaskBtn: document.getElementById('save-task-btn'),
        cancelTaskBtn: document.getElementById('cancel-task-btn'),
        voiceInputBtn: document.getElementById('voice-input-btn'),
        
        // Task List
        taskList: document.getElementById('task-list'),
        emptyState: document.querySelector('.empty-state'),
        
        // Filters
        filterTabs: document.querySelectorAll('.filter-tab'),
        categoryFilters: document.querySelectorAll('.category-filter'),
        searchInput: document.getElementById('search-input'),
        
        // Stats
        totalTasks: document.getElementById('total-tasks'),
        activeTasks: document.getElementById('active-tasks'),
        completedTasks: document.getElementById('completed-tasks'),
        overdueTasks: document.getElementById('overdue-tasks'),
        
        // Actions
        clearCompletedBtn: document.getElementById('clear-completed'),
        exportTasksBtn: document.getElementById('export-tasks'),
        importTasksBtn: document.getElementById('import-tasks'),
        importFileInput: document.getElementById('import-file'),
        
        // Settings
        settingsBtn: document.getElementById('settings-btn'),
        settingsModal: document.getElementById('settings-modal'),
        closeModal: document.querySelector('.close-modal'),
        notificationToggle: document.getElementById('notification-toggle'),
        soundToggle: document.getElementById('sound-toggle'),
        backupToggle: document.getElementById('backup-toggle'),
        resetDataBtn: document.getElementById('reset-data'),
        
        // PWA
        installBtn: document.getElementById('install-btn'),
        
        // Notifications
        notificationContainer: document.getElementById('notification-container')
    };
    
    // State
    let currentFilter = 'all';
    let currentCategory = 'all';
    let currentSearch = '';
    let editingTaskId = null;
    let sortable = null;
    
    /**
     * Initialize UI
     */
    const init = function() {
        // Set up event listeners
        setupEventListeners();
        
        // Initialize sortable for drag & drop
        initSortable();
        
        // Load settings
        loadSettings();
        
        // Render tasks
        renderTasks();
        
        // Update stats
        updateStats();
        
        // Check for PWA installability
        checkPWAInstallability();
    };
    
    /**
     * Set up event listeners
     */
    const setupEventListeners = function() {
        // Theme toggle
        elements.themeToggle.addEventListener('click', toggleTheme);
        
        // Task form
        elements.addTaskBtn.addEventListener('click', showTaskForm);
        elements.saveTaskBtn.addEventListener('click', saveTask);
        elements.cancelTaskBtn.addEventListener('click', hideTaskForm);
        elements.voiceInputBtn.addEventListener('click', startVoiceInput);
        
        // Task input enter key
        elements.taskInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                saveTask();
            }
        });
        
        // Filters
        elements.filterTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                setFilter(this.dataset.filter);
            });
        });
        
        elements.categoryFilters.forEach(filter => {
            filter.addEventListener('click', function() {
                setCategoryFilter(this.dataset.category);
            });
        });
        
        // Search
        elements.searchInput.addEventListener('input', function() {
            currentSearch = this.value.toLowerCase();
            renderTasks();
        });
        
        // Actions
        elements.clearCompletedBtn.addEventListener('click', clearCompleted);
        elements.exportTasksBtn.addEventListener('click', exportTasks);
        elements.importTasksBtn.addEventListener('click', function() {
            elements.importFileInput.click();
        });
        elements.importFileInput.addEventListener('change', importTasks);
        
        // Settings
        elements.settingsBtn.addEventListener('click', showSettings);
        elements.closeModal.addEventListener('click', hideSettings);
        elements.settingsModal.addEventListener('click', function(e) {
            if (e.target === this) {
                hideSettings();
            }
        });
        elements.notificationToggle.addEventListener('change', saveSettings);
        elements.soundToggle.addEventListener('change', saveSettings);
        elements.backupToggle.addEventListener('change', saveSettings);
        elements.resetDataBtn.addEventListener('click', resetData);
        
        // PWA install
        elements.installBtn.addEventListener('click', installPWA);
        
        // Notification container click for close buttons
        elements.notificationContainer.addEventListener('click', function(e) {
            if (e.target.classList.contains('notification-close')) {
                const notification = e.target.closest('.notification');
                notification.classList.add('fade-out');
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }
        });
    };
    
    /**
     * Initialize sortable for drag & drop
     */
    const initSortable = function() {
        sortable = Sortable.create(elements.taskList, {
            animation: 150,
            ghostClass: 'sortable-ghost',
            chosenClass: 'sortable-chosen',
            dragClass: 'sortable-drag',
            onEnd: function(evt) {
                const tasks = Storage.getTasks();
                const movedTask = tasks.splice(evt.oldIndex, 1)[0];
                tasks.splice(evt.newIndex, 0, movedTask);
                Storage.saveTasks(tasks);
                
                // Show notification
                showNotification('Task order updated', 'success');
            }
        });
    };
    
    /**
     * Toggle theme
     */
    const toggleTheme = function() {
        const body = document.body;
        const themeIcon = elements.themeToggle.querySelector('i');
        
        if (body.classList.contains('light-theme')) {
            body.classList.remove('light-theme');
            body.classList.add('dark-theme');
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
            
            // Save setting
            const settings = Storage.getSettings();
            settings.theme = 'dark';
            Storage.saveSettings(settings);
        } else if (body.classList.contains('dark-theme')) {
            body.classList.remove('dark-theme');
            body.classList.add('glassmorphism-theme');
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-glass-martini');
            
            // Save setting
            const settings = Storage.getSettings();
            settings.theme = 'glassmorphism';
            Storage.saveSettings(settings);
        } else if (body.classList.contains('glassmorphism-theme')) {
            body.classList.remove('glassmorphism-theme');
            body.classList.add('neumorphism-theme');
            themeIcon.classList.remove('fa-glass-martini');
            themeIcon.classList.add('fa-cube');
            
            // Save setting
            const settings = Storage.getSettings();
            settings.theme = 'neumorphism';
            Storage.saveSettings(settings);
        } else {
            body.classList.remove('neumorphism-theme');
            body.classList.add('light-theme');
            themeIcon.classList.remove('fa-cube');
            themeIcon.classList.add('fa-moon');
            
            // Save setting
            const settings = Storage.getSettings();
            settings.theme = 'light';
            Storage.saveSettings(settings);
        }
    };
    
    /**
     * Load settings
     */
    const loadSettings = function() {
        const settings = Storage.getSettings();
        
        // Set theme
        document.body.className = `${settings.theme}-theme`;
        
        // Update theme icon
        const themeIcon = elements.themeToggle.querySelector('i');
        if (settings.theme === 'dark') {
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
        } else if (settings.theme === 'glassmorphism') {
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-glass-martini');
        } else if (settings.theme === 'neumorphism') {
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-cube');
        }
        
        // Set toggles
        elements.notificationToggle.checked = settings.notifications;
        elements.soundToggle.checked = settings.sound;
        elements.backupToggle.checked = settings.autoBackup;
    };
    
    /**
     * Save settings
     */
    const saveSettings = function() {
        const settings = Storage.getSettings();
        settings.notifications = elements.notificationToggle.checked;
        settings.sound = elements.soundToggle.checked;
        settings.autoBackup = elements.backupToggle.checked;
        Storage.saveSettings(settings);
        
        showNotification('Settings saved', 'success');
    };
    
    /**
     * Show task form
     */
    const showTaskForm = function() {
        elements.taskForm.classList.remove('hidden');
        elements.taskInput.focus();
    };
    
    /**
     * Hide task form
     */
    const hideTaskForm = function() {
        elements.taskForm.classList.add('hidden');
        elements.taskInput.value = '';
        elements.taskDate.value = '';
        elements.taskCategory.value = 'personal';
        elements.taskPriority.value = 'medium';
        editingTaskId = null;
    };
    
    /**
     * Save task
     */
    const saveTask = function() {
        const text = elements.taskInput.value.trim();
        
        if (!text) {
            showNotification('Please enter a task', 'error');
            return;
        }
        
        const taskData = {
            text: text,
            dueDate: elements.taskDate.value || null,
            category: elements.taskCategory.value,
            priority: elements.taskPriority.value
        };
        
        if (editingTaskId) {
            // Update existing task
            Storage.updateTask(editingTaskId, taskData);
            showNotification('Task updated', 'success');
        } else {
            // Add new task
            Storage.addTask(taskData);
            showNotification('Task added', 'success');
        }
        
        hideTaskForm();
        renderTasks();
        updateStats();
        
        // Schedule notification if due date is set
        if (taskData.dueDate) {
            scheduleNotification(taskData);
        }
    };
    
    /**
     * Edit task
     * @param {string} id - Task ID
     */
    const editTask = function(id) {
        const tasks = Storage.getTasks();
        const task = tasks.find(t => t.id === id);
        
        if (!task) return;
        
        editingTaskId = id;
        elements.taskInput.value = task.text;
        elements.taskDate.value = task.dueDate || '';
        elements.taskCategory.value = task.category;
        elements.taskPriority.value = task.priority;
        
        showTaskForm();
    };
    
    /**
     * Toggle task completion
     * @param {string} id - Task ID
     */
    const toggleTaskCompletion = function(id) {
        Storage.toggleTaskCompletion(id);
        renderTasks();
        updateStats();
        
        // Play sound if enabled
        const settings = Storage.getSettings();
        if (settings.sound) {
            playSound();
        }
    };
    
    /**
     * Delete task
     * @param {string} id - Task ID
     */
    const deleteTask = function(id) {
        Storage.deleteTask(id);
        renderTasks();
        updateStats();
        showNotification('Task deleted', 'success');
    };
    
    /**
     * Set filter
     * @param {string} filter - Filter value
     */
    const setFilter = function(filter) {
        currentFilter = filter;
        
        // Update active tab
        elements.filterTabs.forEach(tab => {
            if (tab.dataset.filter === filter) {
                tab.classList.add('active');
            } else {
                tab.classList.remove('active');
            }
        });
        
        renderTasks();
    };
    
    /**
     * Set category filter
     * @param {string} category - Category value
     */
    const setCategoryFilter = function(category) {
        currentCategory = category;
        
        // Update active filter
        elements.categoryFilters.forEach(filter => {
            if (filter.dataset.category === category) {
                filter.classList.add('active');
            } else {
                filter.classList.remove('active');
            }
        });
        
        renderTasks();
    };
    
    /**
     * Render tasks
     */
    const renderTasks = function() {
        const tasks = Storage.getTasks();
        
        // Filter tasks
        let filteredTasks = tasks.filter(task => {
            // Status filter
            if (currentFilter === 'active' && task.completed) return false;
            if (currentFilter === 'completed' && !task.completed) return false;
            
            // Category filter
            if (currentCategory !== 'all' && task.category !== currentCategory) return false;
            
            // Search filter
            if (currentSearch && !task.text.toLowerCase().includes(currentSearch)) return false;
            
            return true;
        });
        
        // Clear task list
        elements.taskList.innerHTML = '';
        
        // Show empty state if no tasks
        if (filteredTasks.length === 0) {
            elements.taskList.appendChild(elements.emptyState.cloneNode(true));
            return;
        }
        
        // Render each task
        filteredTasks.forEach(task => {
            const taskElement = createTaskElement(task);
            elements.taskList.appendChild(taskElement);
        });
    };
    
    /**
     * Create task element
     * @param {Object} task - Task object
     * @returns {HTMLElement} Task element
     */
    const createTaskElement = function(task) {
        const taskItem = document.createElement('div');
        taskItem.className = `task-item ${task.completed ? 'completed' : ''}`;
        taskItem.dataset.id = task.id;
        
        // Checkbox
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'task-checkbox';
        checkbox.checked = task.completed;
        checkbox.addEventListener('change', () => toggleTaskCompletion(task.id));
        
        // Content
        const content = document.createElement('div');
        content.className = 'task-content';
        
        // Text
        const text = document.createElement('div');
        text.className = 'task-text';
        text.textContent = task.text;
        text.addEventListener('click', () => editTask(task.id));
        
        // Meta
        const meta = document.createElement('div');
        meta.className = 'task-meta';
        
        // Category
        if (task.category) {
            const category = document.createElement('span');
            category.className = `task-category category-${task.category}`;
            
            let categoryIcon = '';
            switch (task.category) {
                case 'personal':
                    categoryIcon = 'fa-user';
                    break;
                case 'work':
                    categoryIcon = 'fa-briefcase';
                    break;
                case 'shopping':
                    categoryIcon = 'fa-shopping-cart';
                    break;
                case 'health':
                    categoryIcon = 'fa-heartbeat';
                    break;
                default:
                    categoryIcon = 'fa-tag';
            }
            
            category.innerHTML = `<i class="fas ${categoryIcon}"></i> ${task.category.charAt(0).toUpperCase() + task.category.slice(1)}`;
            meta.appendChild(category);
        }
        
        // Priority
        if (task.priority) {
            const priority = document.createElement('span');
            priority.className = `task-priority priority-${task.priority}`;
            
            let priorityIcon = '';
            switch (task.priority) {
                case 'high':
                    priorityIcon = 'fa-exclamation-circle';
                    break;
                case 'medium':
                    priorityIcon = 'fa-minus-circle';
                    break;
                case 'low':
                    priorityIcon = 'fa-arrow-down';
                    break;
            }
            
            priority.innerHTML = `<i class="fas ${priorityIcon}"></i> ${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}`;
            meta.appendChild(priority);
        }
        
        // Due date
        if (task.dueDate) {
            const dueDate = document.createElement('span');
            dueDate.className = 'task-due-date';
            
            const dueDateObj = new Date(task.dueDate);
            const now = new Date();
            const isOverdue = dueDateObj < now && !task.completed;
            
            if (isOverdue) {
                dueDate.classList.add('overdue');
            }
            
            const formattedDate = formatDate(dueDateObj);
            dueDate.innerHTML = `<i class="fas fa-calendar"></i> ${formattedDate}`;
            meta.appendChild(dueDate);
        }
        
        content.appendChild(text);
        content.appendChild(meta);
        
        // Actions
        const actions = document.createElement('div');
        actions.className = 'task-actions';
        
        // Edit button
        const editBtn = document.createElement('button');
        editBtn.className = 'task-btn';
        editBtn.innerHTML = '<i class="fas fa-edit"></i>';
        editBtn.addEventListener('click', () => editTask(task.id));
        actions.appendChild(editBtn);
        
        // Delete button
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'task-btn delete';
        deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
        deleteBtn.addEventListener('click', () => deleteTask(task.id));
        actions.appendChild(deleteBtn);
        
        // Append all elements
        taskItem.appendChild(checkbox);
        taskItem.appendChild(content);
        taskItem.appendChild(actions);
        
        return taskItem;
    };
    
    /**
     * Format date
     * @param {Date} date - Date object
     * @returns {string} Formatted date string
     */
    const formatDate = function(date) {
        const options = { 
            month: 'short', 
            day: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
        };
        
        return date.toLocaleDateString(undefined, options);
    };
    
    /**
     * Update stats
     */
    const updateStats = function() {
        const tasks = Storage.getTasks();
        const now = new Date();
        
        const total = tasks.length;
        const completed = tasks.filter(task => task.completed).length;
        const active = total - completed;
        
        // Count overdue tasks
        const overdue = tasks.filter(task => {
            if (task.completed || !task.dueDate) return false;
            const dueDate = new Date(task.dueDate);
            return dueDate < now;
        }).length;
        
        elements.totalTasks.textContent = total;
        elements.activeTasks.textContent = active;
        elements.completedTasks.textContent = completed;
        elements.overdueTasks.textContent = overdue;
    };
    
    /**
     * Clear completed tasks
     */
    const clearCompleted = function() {
        const count = Storage.clearCompletedTasks();
        if (count > 0) {
            renderTasks();
            updateStats();
            showNotification(`${count} completed task${count !== 1 ? 's' : ''} cleared`, 'success');
        } else {
            showNotification('No completed tasks to clear', 'info');
        }
    };
    
    /**
     * Export tasks
     */
    const exportTasks = function() {
        const tasksJSON = Storage.exportTasks();
        const blob = new Blob([tasksJSON], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `tasks-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        showNotification('Tasks exported successfully', 'success');
    };
    
    /**
     * Import tasks
     * @param {Event} event - File input change event
     */
    const importTasks = function(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = function(e) {
            const result = Storage.importTasks(e.target.result);
            
            if (result.success) {
                renderTasks();
                updateStats();
                showNotification(result.message, 'success');
            } else {
                showNotification(result.message, 'error');
            }
        };
        reader.readAsText(file);
        
        // Reset file input
        event.target.value = '';
    };
    
    /**
     * Show settings modal
     */
    const showSettings = function() {
        elements.settingsModal.classList.add('active');
    };
    
    /**
     * Hide settings modal
     */
    const hideSettings = function() {
        elements.settingsModal.classList.remove('active');
    };
    
    /**
     * Reset data
     */
    const resetData = function() {
        if (confirm('Are you sure you want to reset all data? This cannot be undone.')) {
            Storage.resetData();
            renderTasks();
            updateStats();
            showNotification('All data has been reset', 'success');
        }
    };
    
    /**
     * Show notification
     * @param {string} message - Notification message
     * @param {string} type - Notification type (success, error, warning, info)
     */
    const showNotification = function(message, type = 'info') {
        const settings = Storage.getSettings();
        if (!settings.notifications) return;
        
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        
        let icon = '';
        let title = '';
        
        switch (type) {
            case 'success':
                icon = 'fa-check-circle';
                title = 'Success';
                break;
            case 'error':
                icon = 'fa-times-circle';
                title = 'Error';
                break;
            case 'warning':
                icon = 'fa-exclamation-triangle';
                title = 'Warning';
                break;
            case 'info':
                icon = 'fa-info-circle';
                title = 'Info';
                break;
        }
        
        notification.innerHTML = `
            <div class="notification-icon">
                <i class="fas ${icon}"></i>
            </div>
            <div class="notification-content">
                <div class="notification-title">${title}</div>
                <div class="notification-message">${message}</div>
            </div>
            <button class="notification-close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        elements.notificationContainer.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            notification.classList.add('fade-out');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }, 5000);
    };
    
    /**
     * Schedule notification for task
     * @param {Object} task - Task object
     */
    const scheduleNotification = function(task) {
        if (!task.dueDate) return;
        
        const dueDate = new Date(task.dueDate);
        const now = new Date();
        const timeUntilDue = dueDate.getTime() - now.getTime();
        
        // Only schedule if in the future
        if (timeUntilDue <= 0) return;
        
        // Schedule notification 1 hour before due date
        const notificationTime = Math.max(timeUntilDue - 60 * 60 * 1000, 0);
        
        setTimeout(() => {
            const settings = Storage.getSettings();
            if (settings.notifications && Notification.permission === 'granted') {
                new Notification('Task Due Soon', {
                    body: `"${task.text}" is due in 1 hour`,
                    icon: '/assets/icons/icon-192x192.png'
                });
            }
        }, notificationTime);
    };
    
    /**
     * Play sound effect
     */
    const playSound = function() {
        // Create a simple beep sound using Web Audio API
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.type = 'sine';
            oscillator.frequency.value = 800;
            gainNode.gain.value = 0.1;
            
            oscillator.start();
            setTimeout(() => {
                oscillator.stop();
            }, 100);
        } catch (e) {
            console.error('Error playing sound:', e);
        }
    };
    
    /**
     * Start voice input
     */
    const startVoiceInput = function() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            showNotification('Speech recognition not supported in your browser', 'error');
            return;
        }
        
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';
        
        recognition.onstart = function() {
            elements.voiceInputBtn.innerHTML = '<i class="fas fa-stop"></i>';
            elements.voiceInputBtn.classList.add('recording');
        };
        
        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            elements.taskInput.value = transcript;
        };
        
        recognition.onerror = function(event) {
            showNotification('Speech recognition error: ' + event.error, 'error');
            elements.voiceInputBtn.innerHTML = '<i class="fas fa-microphone"></i>';
            elements.voiceInputBtn.classList.remove('recording');
        };
        
        recognition.onend = function() {
            elements.voiceInputBtn.innerHTML = '<i class="fas fa-microphone"></i>';
            elements.voiceInputBtn.classList.remove('recording');
        };
        
        recognition.start();
    };
    
    /**
     * Check PWA installability
     */
    const checkPWAInstallability = function() {
        window.addEventListener('beforeinstallprompt', (e) => {
            // Prevent the mini-infobar from appearing on mobile
            e.preventDefault();
            // Stash the event so it can be triggered later
            window.deferredPrompt = e;
            // Update UI notify the user they can install the PWA
            elements.installBtn.style.display = 'inline-flex';
        });
        
        window.addEventListener('appinstalled', () => {
            // Hide the install button
            elements.installBtn.style.display = 'none';
            showNotification('App installed successfully', 'success');
        });
    };
    
    /**
     * Install PWA
     */
    const installPWA = function() {
        if (!window.deferredPrompt) {
            showNotification('App cannot be installed', 'error');
            return;
        }
        
        // Show the install prompt
        window.deferredPrompt.prompt();
        
        // Wait for the user to respond to the prompt
        window.deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                showNotification('App installation accepted', 'success');
            } else {
                showNotification('App installation declined', 'info');
            }
            // Clear the deferred prompt
            window.deferredPrompt = null;
        });
    };
    
    // Public API
    return {
        init
    };
})();